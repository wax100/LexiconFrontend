<?php

$_lang['lexiconfrontend'] = 'Lexicon Frontend';
$_lang['lexiconfrontend_menu_desc'] = 'Lexicon fot frontend';
$_lang['lf_title'] = 'Lexicon Frontend';
$_lang['lf_title_tab'] = 'Lexicon';
$_lang['lf_description'] = 'Change language strings in the template';