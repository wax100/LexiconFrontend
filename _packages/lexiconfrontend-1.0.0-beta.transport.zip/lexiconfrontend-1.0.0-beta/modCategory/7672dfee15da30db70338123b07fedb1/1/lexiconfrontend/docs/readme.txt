--------------------
lexiconFrontend
--------------------
Author: Andrei Gadashevich <gav.andrei@makebecool.com>
--------------------

This extension to manage the language strings in templates.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/username/lexiconFrontend/issues